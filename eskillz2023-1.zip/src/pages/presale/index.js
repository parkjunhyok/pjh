
import React from 'react';
import { Button, makeStyles, TextField} from '@material-ui/core';
import FileUpload from 'react-material-file-upload';
import styles from './style';
import { ethers } from 'ethers'

const PresaleContractABI = require('../../Presale.json');
const PresaleContractAddress = "0x97BBF34109875FEe6dB01b055d64dFe7d32EA4C4";
const Web3 = require("web3");

let web3 = new Web3(
    new Web3.providers.WebsocketProvider("wss://ropsten.infura.io/ws/v3/acc8266b5baf41c5ad44a05fe4a49925")
);
const useStyles = makeStyles(styles);

function PresalePage() {
  const classes = useStyles();
  const [ethAmount, setEthAmount] = React.useState("");
  const [esgAmount, setEsgAmount] = React.useState("");

  const buy = async () => {  
    const { ethereum } = window;
    if (ethereum) {
      const chainIDBuffer = await ethereum.networkVersion;
      if(chainIDBuffer == 3){
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const PresaleContract = new ethers.Contract(PresaleContractAddress, PresaleContractABI, signer);
        try {
          let nftTxn = await PresaleContract.buy(
            {
              value: ethers.utils.parseUnits(ethAmount.toString(), 'ether')._hex,
            }        
          );              
        } catch (err) {          
          return {
            error: err        
          };
        }            
      }   
    }
  }

  return (
    <>
       <Button className={classes.circle_btn} onClick={() => window.location.replace('/mint')}>
        {'<'}
      </Button>
      <div className={classes.hero}>          
        <div className={classes.infos}>
          <span>Amount of ETH being spent</span>
          <TextField
            placeholder="217"
            variant="filled"      
            value = {ethAmount}      
            onChange={(event) => setEthAmount(event.target.value)}
          />
          <span>Tokens to be purchased</span>
          <span>+ </span>                 
           
          <Button id="submit" variant="contained" onClick = {() =>{buy()}}>
            BUY
          </Button>          
        </div>      
                   
        {/* <FileUpload
          accept={['image/jpeg', 'image/png', 'video/mp4']}
          title="JPG, PNG or MP4 videos accepted. 10MB limit."
          buttonText="Click to upload"
          maxSize={1024*1024*10}
          value={files}
          onChange={setFiles}
        />   */}
             
      </div>
    </>
  );
}

export default PresalePage;