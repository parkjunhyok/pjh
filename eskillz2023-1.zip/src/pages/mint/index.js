
import React from 'react';
import { Button, makeStyles, TextField} from '@material-ui/core';
import FileUpload from 'react-material-file-upload';
import styles from './style';
import { ToggleButton, ToggleButtonGroup} from '@mui/material';
import { ethers } from 'ethers'
const axios = require('axios');
const IpfsHttpClient = require("ipfs-http-client");
const ipfsC = IpfsHttpClient.create({
  host: "ipfs.infura.io",
  port: "5001",
  protocol: "https",
});

const NFTcontractABI = require('../../NFT.json');
const MarketcontractABI = require('../../Marketplace.json');
const NFTcontractAddress = "0x2dC7DE43f04Cf66fA0fa25cDAD796Ff3fcF9e56A";
const MarketcontractAddress = "0x5ef97ACc5C9b671f9c59f214b5733635580ef089";
const Web3 = require("web3");

let web3 = new Web3(
    new Web3.providers.WebsocketProvider("wss://ropsten.infura.io/ws/v3/acc8266b5baf41c5ad44a05fe4a49925")
);
const useStyles = makeStyles(styles);

const Quantity = (props) => {
  const classes = useStyles();
  const { quantity, setQuantity } = props;
  return (
    <div className={classes.quantity}>
      <Button variant="contained" onClick={() => setQuantity(quantity - 1)} disabled={quantity === 1}>-</Button>
      <span>{quantity}</span>
      <Button variant="contained" onClick={() => setQuantity(quantity + 1)}>+</Button>
    </div>
  )
}

function MintPage() {
  const classes = useStyles();
  const [files, setFiles] = React.useState([]);
  const [nftType, setNftType] = React.useState(0);
  const [quantity, setQuantity] = React.useState(1);
  const [imgHash, setImgHash] = React.useState("");
  const [imgName, setImageName] = React.useState("");
  const [imgDescription, setImageDescription] = React.useState("");
  const [metadaState, setMetadaState] = React.useState("");
  const upload = async (e) => {
    if(imgHash !="Pending"){
      if(e.target.files.length>0){
        setImgHash("Pending");
        const addedToIPFS = await ipfsC.add(e.target.files[0]);
        //console.log(added);
        setImgHash(addedToIPFS.path);  
      }
      else{
        setImgHash("");
      }
    }   
      
   };

   const uploadMetaData = async () => {
    if (imgName.trim() == "" || (imgDescription.trim() == "" || imgHash.trim() == "" || imgHash.trim() == "Pending")) { 
        setMetadaState("❗Please make sure all fields are completed before minting.");      
    }
    else{
      // make metaData
      if(metadaState != "Pending"){
        setMetadaState("Pending");
        const metadata = new Object();
        metadata.name = imgName;
        metadata.image_url = "https://gateway.pinata.cloud/ipfs/" + imgHash;
        metadata.description = imgDescription;   
        metadata.level = 2;
        metadata.exp = 80;
        metadata.currentPower = 10;
        metadata.totalPower = 20;
        metadata.force = 4;
        metadata.aim = 2;
        metadata.spin = 3;
        metadata.time = 1;            
        //make pinata call
        const pinataResponse = await pinJSONToIPFS(metadata);
        if (!pinataResponse.success) {
          setMetadaState("😢 Something went wrong while uploading your tokenURI.");          
        } 
        else{
          setMetadaState("PinataHash : " + pinataResponse.pinataUrl);
          const tokenURI = pinataResponse.pinataUrl;    
          mintNft(tokenURI, metadata);      
        }
      }
    }  
  };

  const pinJSONToIPFS = async(JSONBody) => {
    const url = `https://api.pinata.cloud/pinning/pinJSONToIPFS`;
    //making axios POST request to Pinata ⬇️
    return axios 
        .post(url, JSONBody, {
            headers: {
                pinata_api_key: "238047f870c7ab07af4b",
                pinata_secret_api_key: "1b57450a5dc199dd620cca759bf665c8abc323278469baf2368cb3d8372d9a6f",
            }
        })
        .then(function (response) {
           return {
               success: true,
               pinataUrl: "https://gateway.pinata.cloud/ipfs/" + response.data.IpfsHash
           };
        })
        .catch(function (error) {
            console.log(error)
            return {
                success: false,
                message: error.message,
            }

        });
  };

  async function mintNft(_tokenUri, _metadata) {    
    
    const { ethereum } = window;
    if (ethereum) {
      const chainIDBuffer = await ethereum.networkVersion;
      if(chainIDBuffer == 3){
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const contractNFT = new ethers.Contract(NFTcontractAddress, NFTcontractABI, signer);
        const contractMark = new ethers.Contract(MarketcontractAddress, MarketcontractABI, signer);
        try {
          let nftTxn = await contractNFT.createToken(_tokenUri);
          await nftTxn.wait(); 
          
          // web3.eth.getTransactionReceipt(nftTxn.hash).then(async function(data){
          //   let logs = data.logs;
          //   //console.log(web3.utils.hexToNumber(logs[0].topics[3]));
          //   _metadata.tokenID = web3.utils.hexToNumber(logs[0].topics[3]);
          //   let nfttxn1 = await contractMark.createMarketItem(web3.utils.hexToNumber(logs[0].topics[3]), NFTcontractAddress);
          // });        
        } catch (err) {          
          return {
            error: err        
          };
        }            
      }   
    }
  }

  return (
    <>
       <Button className={classes.circle_btn} onClick={() => window.location.replace('/')}>
        {'<'}
      </Button>
      <div className={classes.hero}>   
        <img src="/images/mint_logo.png" alt="" />
        <div className={classes.infos}>
          <span>Title</span>
          <TextField
            placeholder="Hall of fame"
            variant="filled"      
            value = {imgName}      
            onChange={(event) => setImageName(event.target.value)}
          />
          <span>Description</span>
          <TextField
            placeholder="A description about your NFT"
            variant="filled"
            multiline
            rows={4}   
            value = {imgDescription}         
            onChange={(event) => setImageDescription(event.target.value)}
          />
          <div id="toggles">
            <div>
              <span>NFT Type</span>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={nftType}
                onChange={(e, v) => v !== null ? setNftType(v) : ''}
              >
                <ToggleButton value={0}>ERC721</ToggleButton>
                <ToggleButton value={1}>ERC1155</ToggleButton>
              </ToggleButtonGroup>
            </div>
            <div>
              <span>Quantity</span>
              <Quantity quantity={quantity} setQuantity={setQuantity} />
            </div>
          </div>
          <span>Social Media URL (Optional)</span>
          <TextField
            placeholder="https://twitter.com/example"
            variant="filled"
          />
          <Button id="submit" variant="contained" onClick = {() =>{uploadMetaData()}}>
            Submit
          </Button>
          <span style={{margin : "20px 0px 0px 0px"}}>
            {metadaState}
          </span>
        </div>
        <div className={classes.vertical_line} />
        <div className={classes.infos} style={{alignItems : 'center'}}>
          <span variant="filled" >JPG, PNG or MP4 videos accepted. 10MB limit.</span>
          <input
            type="file"
            accept={['image/jpeg', 'image/png', 'video/mp4']}
            maxSize={1024*1024*10}
            style={{ display: 'none' }}
            id="contained-button-file"
            onChange={(e) => { upload(e);}}
          />
          <label htmlFor="contained-button-file">
            <Button variant="contained" component="span">
              Upload Image
            </Button>
          </label>   
          <span style={{margin : "20px 0px 0px 0px"}}>
            {imgHash}
          </span>
        </div>
                   
        {/* <FileUpload
          accept={['image/jpeg', 'image/png', 'video/mp4']}
          title="JPG, PNG or MP4 videos accepted. 10MB limit."
          buttonText="Click to upload"
          maxSize={1024*1024*10}
          value={files}
          onChange={setFiles}
        />   */}
             
      </div>
    </>
  );
}

export default MintPage;