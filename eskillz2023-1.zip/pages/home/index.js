
import React from 'react';
import HomePage from '../../src/pages/home';

function Home() {

  return (
    <HomePage />
  );
}

export default Home;