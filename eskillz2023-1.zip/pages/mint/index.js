
import React from 'react';
import MintPage from '../../src/pages/mint';

function Home() {

  return (
    <MintPage />
  );
}

export default Home;