import React from 'react';
import Home from './home';
import Mint from './mint';

export default function Index() {
  return (
    <Home />
    //<Mint />
  );
}
