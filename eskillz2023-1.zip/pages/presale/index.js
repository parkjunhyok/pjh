
import React from 'react';
import PresalePage from '../../src/pages/presale';

function Home() {

  return (
    <PresalePage />
  );
}

export default Home;