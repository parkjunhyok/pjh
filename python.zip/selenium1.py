"""
from webdriver_manager.chrome import ChromeDriverManager
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
#browser exposes an executable file
#Through Selenium test we will invoke the executable file which will then #invoke actual browser
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
# to maximize the browser window
driver.maximize_window()
#get method to launch the URL
driver.get("https://www.tutorialspoint.com/index.htm")
#to refresh the browser
driver.refresh()
# identifying the edit box with the help of id and enter text
driver.find_element_by_id("gsc-i-id1").send_keys("Selenium")
# submit the text contents
driver.find_element_by_id("gsc-i-id1").submit()
#to close the browser
driver.close()
"""
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument('--headless')
driver = webdriver.Chrome(options=options)

driver.maximize_window()
#get method to launch the URL
driver.get("https://www.tutorialspoint.com/index.htm")
print(driver.text)
#to refresh the browser
driver.refresh()
# identifying the edit box with the help of id and enter text
driver.find_element_by_id("gsc-i-id1").send_keys("Selenium")
# submit the text contents
driver.find_element_by_id("gsc-i-id1").submit()
#to close the browser
driver.close()