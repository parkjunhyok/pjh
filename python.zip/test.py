import mechanicalsoup
import time
# 1
browser = mechanicalsoup.Browser()
url = "https://cosmiccredits.com/"
login_page = browser.get(url)
login_html = login_page.soup
print(login_html)

# 2
form = login_html.select("#m_form_login")[0]
login_html.select("#clanname")[0]["value"] = "student"
login_html.select("#clanpassword")[0]["value"] = "student"

# 3 m_form_login
profiles_page = browser.submit(form, login_page.url)
print(profiles_page)

"""
for i in range(4):
    page = browser.get("http://olympus.realpython.org/dice")
    tag = page.soup.select("#result")[0]
    result = tag.text
    print(f"The result of your dice roll is: {result}")

    # Wait 10 seconds if this isn't the last request
    if i < 3:
        time.sleep(10)
"""
