a = 3
b = 5
f = a + b
print(f)