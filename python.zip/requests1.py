import requests
s = requests.Session()
url = 'https://cosmiccredits.com/index.php/ClanLogin?dt=Thu%20Feb%2009%202023%2002:47:49%20GMT+0100%20(Central%20European%20Standard%20Time)&clanname=student&clanpassword=student&remember=on'
r = s.get(url)
print(r)

r = s.get('https://cosmiccredits.com/index.php/Clan_quarters/isValidPassword?dt=Thu%20Feb%2009%202023%2002:51:47%20GMT+0100%20(Central%20European%20Standard%20Time)&clanid=32&userid=36&password=student')
print(r)
