import Metamask from "../icons/Metamask";
import MathWallet from "../icons/MathWallet";
import TokenPocket from "../icons/TokenPocket";
import TrustWallet from "../icons/TrustWallet";
import WalletConnect from "../icons/WalletConnect";
import BinanceChain from "../icons/BinanceChain";
import SafePalWallet from "../icons/SafePalWallet";
import Coinbase from "../icons/Coinbase";
import Blocto from "../icons/Blocto";
import Bitkeeper from "../icons/Bitkeeper";
export const ConnectorNames = {
  Injected: "injected",
  WalletConnect: "walletconnect",
  BSC: "bsc",
  Blocto: "blocto",
  WalletLink: "walletlink",
};
export const connectors_data = [
  {
    title: "Metamask",
    icon: Metamask,
    connectorId: ConnectorNames.Injected,
  },
  {
    title: "Trust Wallet",
    icon: TrustWallet,
    connectorId: ConnectorNames.WalletConnect,
  },
  {
    title: "MathWallet",
    icon: MathWallet,
    connectorId: ConnectorNames.Injected,
  },
  {
    title: "TokenPocket",
    icon: TokenPocket,
    connectorId: ConnectorNames.Injected,
  },
  {
    title: "WalletConnect",
    icon: WalletConnect,
    connectorId: ConnectorNames.WalletConnect,
  },
  {
    title: "Binance Chain",
    icon: BinanceChain,
    connectorId: ConnectorNames.BSC,
  },
  {
    title: "SafePal",
    icon: SafePalWallet,
    connectorId: ConnectorNames.Injected,
  },
  {
    title: "Blocto",
    icon: Blocto,
    connectorId: ConnectorNames.Blocto,
  },
  {
    title: "Coinbase",
    icon: Coinbase,
    connectorId: ConnectorNames.WalletLink,
  },
  {
    title: "Bitkeep",
    icon: Bitkeeper,
    connectorId: ConnectorNames.Injected,
  },
];

// export default connectors;
export const connectorLocalStorageKey = "connectorId";
