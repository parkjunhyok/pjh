import React from "react";
import blocto from "../../../assets/image/wallet/Blocto_logo.png";

const Icon = (props) => {
  return <img src={blocto} width={25} height={30} alt="blocto" />;
};

export default Icon;
