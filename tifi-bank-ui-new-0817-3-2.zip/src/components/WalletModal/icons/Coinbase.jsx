import React from "react";
import coinbase from "../../../assets/image/wallet/coinbase.png";

const Icon = (props) => {
  return <img src={coinbase} {...props} alt="coinbase" />;
};

export default Icon;
