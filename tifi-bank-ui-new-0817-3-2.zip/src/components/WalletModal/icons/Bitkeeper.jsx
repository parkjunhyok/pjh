import React from "react";
import bitkeeper from "../../../assets/image/wallet/bitkeep-icon.svg";

const Icon = (props) => {
  return <img src={bitkeeper} width={25} height={30} alt="bitkeep" />;
};

export default Icon;
