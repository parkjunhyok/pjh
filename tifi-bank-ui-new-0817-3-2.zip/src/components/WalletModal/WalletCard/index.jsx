import { ButtonBase, Grid, styled, Typography } from "@mui/material";
import { blue } from "@mui/material/colors";
import React from "react";
import { connectorLocalStorageKey } from "../config";
const Root = styled(ButtonBase)(({ theme }) => ({
  border: "1px solid #000",
  borderRadius: 18,
  background: blue[600],
  width: "100%",
  padding: "10px 20px",
  transition: "ease-out 0.4s",
  "&: hover": {
    background: blue[400],
    transform: "translateY(-3px)",
  },
  margin: "2px",
  cursor: "pointer",
}));
const WalletCard = ({ icon: Icon, name, login, config, handleClose }) => {
  return (
    <Root
      onClick={() => {
        login(config.connectorId);
        window.localStorage.setItem(
          connectorLocalStorageKey,
          config.connectorId
        );
        handleClose();
      }}
    >
      <Grid container justifyContent="space-between" alignItems="center">
        <Grid item>
          <Icon width={30} height={30} />
        </Grid>
        <Grid item>
          <Typography color="white">{name}</Typography>
        </Grid>
      </Grid>
    </Root>
  );
};

export default WalletCard;
