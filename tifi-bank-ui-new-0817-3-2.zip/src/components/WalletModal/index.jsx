import { CloseOutlined } from "@mui/icons-material";
import {
  Button,
  Dialog,
  DialogTitle,
  IconButton,
  Typography,
  useTheme,
  Grid,
} from "@mui/material";
import Divider from "@mui/material/Divider";
import React from "react";
import { useState } from "react";
import useTranslation from "../../context/Localization/useTranslation";
import useAuth from "../WalletConnectButton/utils/useAuth";
import { connectors_data } from "./config";
import WalletCard from "./WalletCard";

const WalletModal = ({ type }) => {
  const [open, setOpen] = useState(false);
  const { login } = useAuth();
  const { t } = useTranslation();
  const theme = useTheme();
  return (
    <>
      {type ? (
        <Button
          // variant="contained"
          fullWidth
          sx={theme.custom.swapButton}
          onClick={() => setOpen(true)}
        >
          {t("Connect Wallet")}
        </Button>
      ) : (
        <Button onClick={() => setOpen(true)}> {t("Connect Wallet")}</Button>
      )}
      <Dialog
        maxWidth={"xs"}
        PaperProps={{
          sx: {
            borderRadius: 4,
            padding: "2px 20px",
            background: "#27262C",

            filter: "blue(6px)",
            position: "relative",
          },
        }}
        open={open}
        onClose={() => setOpen(false)}
      >
        <IconButton
          onClick={() => setOpen(false)}
          sx={{ position: "absolute", top: 4, right: 4 }}
        >
          <CloseOutlined color="white" />
        </IconButton>
        <DialogTitle>
          <Typography color="white">Connect Wallet</Typography>
        </DialogTitle>

        <Grid direction="row" container columnSpacing={2}>
          {connectors_data.map((item, index) => (
            <Grid item sm={6} xs={12}>
              <WalletCard
                icon={item.icon}
                config={item}
                login={login}
                handleClose={() => setOpen(false)}
                key={index}
                name={item.title}
              />
            </Grid>
          ))}
          {/* <Grid item sm={6}>
            {connectors_data.map((item, index) =>
              index % 2 == 1 ? (
                <WalletCard
                  icon={item.icon}
                  config={item}
                  login={login}
                  handleClose={() => setOpen(false)}
                  key={index}
                  name={item.title}
                />
              ) : (
                <></>
              )
            )}
          </Grid> */}
        </Grid>
        <Divider sx={{ m: 2 }} variant="middle" color="white" />
        <Typography
          color="white"
          variant="body2"
          align="center"
          display="block"
        >
          Haven’t got a crypto wallet yet?
        </Typography>
        <Button
          sx={{ m: 2, borderRadius: 18, padding: 2 }}
          target="_blank"
          href="https://walletconnect.com/"
          variant="contained"
        >
          Learn How to Connect
        </Button>
      </Dialog>
    </>
  );
};

export default WalletModal;
