import { InjectedConnector } from "@web3-react/injected-connector";
import { WalletConnectConnector } from "@web3-react/walletconnect-connector";
import { BscConnector } from "@binance-chain/bsc-connector";
import { WalletLinkConnector } from "@web3-react/walletlink-connector";
import { Web3Provider } from "@ethersproject/providers";
import { BloctoConnector } from "@blocto/blocto-connector";
import { ConnectorNames } from "../../WalletModal/config";
import getNodeUrl from "./getRpcUrl";
const POLLING_INTERVAL = 12000;
const rpcUrl = getNodeUrl();
const chainId = parseInt("97", 10);
console.log("connectorName==", ConnectorNames);
const injected = new InjectedConnector({ supportedChainIds: [chainId] });

const walletconnect = new WalletConnectConnector({
  rpc: { [chainId]: rpcUrl },

  qrcode: true,
  pollingInterval: POLLING_INTERVAL,
});

const bscConnector = new BscConnector({ supportedChainIds: [chainId] });

export const connectorsByName = {
  [ConnectorNames.Injected]: injected,
  [ConnectorNames.WalletConnect]: walletconnect,
  [ConnectorNames.BSC]: bscConnector,
  [ConnectorNames.Blocto]: new BloctoConnector({ chainId, rpc: rpcUrl }),

  [ConnectorNames.WalletLink]: new WalletLinkConnector({
    url: rpcUrl,
    appName: "PancakeSwap",
    appLogoUrl: "https://pancakeswap.com/logo.png",
    supportedChainIds: [56, 97],
  }),
};
export const getLibrary = (provider) => {
  const library = new Web3Provider(provider);
  library.pollingInterval = POLLING_INTERVAL;
  return library;
};
