import { combineReducers } from "redux";
import setting from "./setting.reducer";

const settingReducers = combineReducers({
    setting,
});
export default settingReducers;
