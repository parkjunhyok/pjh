export const TOKENS = [
  {
    address: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
    title: "BNB",
    description: "BNB",
    apiId: "bnb",
  },
  {
    address: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56",
    title: "BUSD",
    description: "BUSD Token",
    apiId: "binance-usd",
  },
  {
    address: "0x17E65E6b9B166Fb8e7c59432F0db126711246BC0",
    title: "TIFI",
    description: "TiFi Token",
    apiId: "tifi-token",
  },
  {
    address: "0x55d398326f99059fF775485246999027B3197955",
    title: "USDT",
    description: "Tether",
    apiId: "tether",
  },
  {
    address: "0x6266a18F1605DA94e8317232ffa634C74646ac40",
    title: "MFX",
    description: "MetFX Watch To Earn",
    apiId: "metfx-watch-to-earn",
  }
];
