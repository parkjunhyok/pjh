export const ROOT_PATH = "/bank"
export const BSC_SCAN_URL = "https://bscscan.com/"