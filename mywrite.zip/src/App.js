import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from "react";
import {ethers} from "ethers";
const Web3 = require("web3");

const plusAbi = require('./write.json');
function App() {
  const [address, setAddress] = useState("");
  const [result, setResult] = useState("");
  async function connectwallet(){

    const chainId = 5;
    if (window.ethereum) {
      let web3 = new Web3(window.ethereum);
//      const addressArray = await window.ethereum.request({
//         method: "eth_requestAccounts"});

        // const accounts = await window.ethereum.request({method: 'eth_accounts'});
        
        const addressArray = await window.ethereum.request({
          method: 'wallet_requestPermissions',
          params: [{ eth_accounts: {} }],
        });
        // const addressArray = await window.ethereum.request({method: "eth_requestAccounts"});
        console.log(addressArray[0])
        
        // if (accounts.length) {
            
        //  } else {
        //     const addressArray = await window.ethereum.request({method: "eth_requestAccounts"});
        //  }

         if (window.ethereum.networkVersion !== chainId) {

          await window.ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId:  web3.utils.toHex(chainId) }],
          }); 
              
      }
//      setAddress(addressArray[0]) ;  
      // else{

      // }
    }
  }

  async function get(){

    const chainId = 5;
    if (window.ethereum) {
      let web3 = new Web3(window.ethereum);
      var TokenContract = new web3.eth.Contract(plusAbi,"0xcAC68F926e158Be16314fB82d8A33331c43a76f9");
      var res = await TokenContract.methods.getResult().call();
      setResult(res);
    }
  }
  async function set(){
    const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const nftContract = new ethers.Contract("0xcAC68F926e158Be16314fB82d8A33331c43a76f9", plusAbi, signer);         
      let nftTxn = await nftContract.setResult("1", "2"); 

  }

  return (
    <div className="App">
      <header className="App-header">
      <p className="fore">{result}</p>
        <button onClick={() => {connectwallet();}}>aaaaa</button>
        <button onClick={() => {get();}}>GET</button>
        <button onClick={() => {set();}}>SET</button>
      </header>
    </div>
  );
}

export default App;
